package com.diaspark.dailyburn.util;
import org.openqa.selenium.WebDriver;

public class DriverInstance

{	
	public static  WebDriver app_driver =  ManageBrowser.setBrowser();
	
 	
}
