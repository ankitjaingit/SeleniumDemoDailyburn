package com.diaspark.dailyburn.object_reprository;

public class ProgramsObjectRepository { 
	
	public String Link_Programs_Identifire                         = "xpath";
	public String Link_Programs_Identifire_Value                   = "/html/body/div[2]/div/div[1]/div[1]/section[1]/ul/li[4]/a";
    public String Button_GetStarted_Identifire                     = "xpath";
    public String Button_GetStarted_Identifire_Value               = "/html/body/div[2]/div/div[2]/div/div[3]/section[2]/div[1]/div[2]/a";
    public String Selector_DOB_Month_Identifire                    = "xpath";
    public String Selector_DOB_Month_Identifire_Value              = "/html/body/div[2]/div/div[2]/div/div[3]/section/div[1]/div/div[2]/div/div[1]/div/div/select" ;
    public String Selector_DOB_Date_Identifire                     = "xpath";
    public String Selector_DOB_Date_Identifire_Value               = "/html/body/div[2]/div/div[2]/div/div[3]/section/div[1]/div/div[2]/div/div[2]/div/div/select";
    public String Selector_DOB_Year_Identifire                     = "xpath";
    public String Selector_DOB_Year_Identifire_Value               = "/html/body/div[2]/div/div[2]/div/div[3]/section/div[1]/div/div[2]/div/div[3]/div/div/select";
    public String TextInput_Weight_Identifire                      = "xpath";
    public String TextInput_Weight_Identifire_Value                = "/html/body/div[2]/div/div[2]/div/div[3]/section/div[1]/div/div[3]/div/div/input";
    public String Button_Next1_Identifire                           = "xpath";
    public String Button_Next_Identifire_Value                     = "/html/body/div[2]/div/div[2]/div/div[3]/div/button";
    public String Button_WorkoutDays_Identifire                    = "xpath";
    public String Button_WorkoutDays_Identifire_Value1             = "/html/body/div[2]/div/div[2]/div/div[3]/section/div[1]/div[2]/div[";   
    public String Button_WorkoutDays_Identifire_Value2             = "]/li";
    public String Button_WorkoutDays_Identifire_Default            = "/html/body/div[2]/div/div[2]/div/div[3]/section/div[1]/div[2]/div[5]/li";     
    public String Button_Next2_Identifire                          = "xpath";
    public String Button_Next2_Identifire_Value                    = "/html/body/div[2]/div/div[2]/div/div[3]/div/button[2]";
    public String ImageEasy_Identifire                             = "className";
    public String ImageEasy_Identifire_Value                       = "dbwf-preference-card";
    public String ImageEasy_Identifire2                            = "xpath";
    public String ImageEasy_Identifire_Value2                      = "/html/body/div[2]/div/div[2]/div/div[3]/section/div[1]/div[1]/div";
    public String Button_FindMyPerfectFit_Identifire               = "xpath";
    public String Button_FindMyPerfectFit_Identifire_Value         = "/html/body/div[2]/div/div[2]/div/div[3]/div/button[2]";
    public String Message_Text_Identifire                          = "xpath";
    public String Message_Test_Identifire_Value                    = "/html/body/div[2]/div/div[2]/div/div[2]/div/div";
    public String Page_Navigation                                  = "xpath";
    public String Page_Navigation_value                            = "/html/body/div[2]/div/div[2]/div/div[3]/div[2]/div[1]/a";
}                                                                     
