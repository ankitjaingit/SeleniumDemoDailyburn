package com.diaspark.dailyburn.util;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ReadProperties
{
	
		// Function written to read details from properties file
			public Properties readProperties(String path) throws IOException 
		    {
	          Properties properties = new Properties();
		      File LoginFile =new File(System.getProperty("user.dir")+ path);
	          FileReader LoginReader = new FileReader(LoginFile);
	          properties.load(LoginReader);  
	          return properties;
	         }

}


