package com.diaspark.dailyburn.util;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SearchElement
{
	
	public WebElement searchElement(WebDriver driver,String identifier, String value)
	{
		WebElement obj_ele=null; 
		switch (identifier)
		{
		  case "id":
		     obj_ele = driver.findElement(By.id(value));
		  break;
		  
		  case"className":
			  obj_ele = driver.findElement(By.className(value));
		  break;
			
	      case"xpath":
		     obj_ele = driver.findElement(By.xpath(value));
	      break;	
	      
		   case"tagName":
	 	      obj_ele = driver.findElement(By.tagName(value));
		   break;	
		}
		return obj_ele;
	
	}


}
