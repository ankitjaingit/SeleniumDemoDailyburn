package com.diaspark.dailyburn.testcases;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.diaspark.dailyburn.object_reprository.ProgramsObjectRepository;
import com.diaspark.dailyburn.util.DriverInstance;
import com.diaspark.dailyburn.util.ReadProperties;
import com.diaspark.dailyburn.util.SearchElement;
import com.diaspark.dailyburn.util.WaitToLoad;

public class ManagePrograms {
	
	public  WebDriver ap_driver =DriverInstance.app_driver;
	ProgramsObjectRepository ProgramsOR = new ProgramsObjectRepository();
	ReadProperties read_Properties = new ReadProperties();
	SearchElement search_Element = new SearchElement();
	WaitToLoad Loading = new WaitToLoad();
	public WebElement Programs,GetStarted,DOB_Month,DOB_Date,DOB_Year,Weight,Next1,Next2,WorkoutDays,StyleOfWorkout,FindMyPerfectFit,FindMyPerfectFitSelect,PreferanceValidationText;
	public String DOBMonth,DOBDate,DOBYear;
	
	@Test (priority=9)	
	// Navigates to programs
	 public void navigatetoPrograms()
	 
	 {
		Programs = Loading.WaitToClickable(ProgramsOR.Link_Programs_Identifire, ProgramsOR.Link_Programs_Identifire_Value);
		Programs.click();
			
	 }
	
	 // Click on Get Started buttons
	 
	@Test (priority=10)	
	// Click on get Started button
	 public void clickGetStartedbutton()
	 
	 {
		GetStarted = Loading.WaitToClickable(ProgramsOR.Button_GetStarted_Identifire, ProgramsOR.Button_GetStarted_Identifire_Value);
		GetStarted.click();
			
	 }
	
	@Test (priority=11)	
	//Update details (about yourself) & click on Next
      
	 public void updateAboutYourself() throws IOException
	 
	 {
		// Select month value
		DOB_Month = Loading.WaitToClickable(ProgramsOR.Selector_DOB_Month_Identifire, ProgramsOR.Selector_DOB_Month_Identifire_Value);
        Select DOB_Month_Values = new Select(DOB_Month);
        DOBMonth = (read_Properties.readProperties("\\src\\test\\java\\com\\diaspark\\dailyburn\\properties\\ProgramsPagePropertise")).getProperty("Programe_DOB_Month");
        DOB_Month_Values.selectByVisibleText(DOBMonth);
        
        // Select date value      
        DOB_Date = Loading.WaitToClickable(ProgramsOR.Selector_DOB_Date_Identifire, ProgramsOR.Selector_DOB_Date_Identifire_Value);
        Select DOB_Date_Values = new Select(DOB_Date);
        DOBDate =  (read_Properties.readProperties("\\src\\test\\java\\com\\diaspark\\dailyburn\\properties\\ProgramsPagePropertise")).getProperty("Programe_DOB_Date");
        DOB_Date_Values.selectByValue(DOBDate);
        
        // Select year value
        DOB_Year = Loading.WaitToClickable(ProgramsOR.Selector_DOB_Year_Identifire, ProgramsOR.Selector_DOB_Year_Identifire_Value);
        Select DOB_Year_Values = new Select(DOB_Year);
        DOBYear =  (read_Properties.readProperties("\\src\\test\\java\\com\\diaspark\\dailyburn\\properties\\ProgramsPagePropertise")).getProperty("Programe_DOB_Year");
        DOB_Year_Values.selectByValue(DOBYear);
        
        //Enter Weigth 
        Weight = Loading.WaitToClickable(ProgramsOR.TextInput_Weight_Identifire,ProgramsOR.TextInput_Weight_Identifire_Value);
        Weight.clear();
        String WeightValue =(read_Properties.readProperties("\\src\\test\\java\\com\\diaspark\\dailyburn\\properties\\ProgramsPagePropertise")).getProperty("Programe_Weight");
        Weight.sendKeys(WeightValue);
       
        // Click on Next button
        Next1 = Loading.WaitToClickable(ProgramsOR.Button_Next1_Identifire, ProgramsOR.Button_Next_Identifire_Value);
        Next1.click();
	 }
	
	@Test (priority=12)
	// Set programme goal
	public void setWorkoutGoal() throws IOException
	
	{
		String Workout_Days_Part1 = ProgramsOR.Button_WorkoutDays_Identifire_Value1 ;
		String Workout_Days_Part2 = ProgramsOR.Button_WorkoutDays_Identifire_Value2; 
		int Day = Integer.parseInt((read_Properties.readProperties("\\src\\test\\java\\com\\diaspark\\dailyburn\\properties\\ProgramsPagePropertise")).getProperty("Programe_WorkoutDays"));
		String Workout_Days_Path = Workout_Days_Part1+Day+Workout_Days_Part2;
		
		if (Day<=7)
		{
		WorkoutDays = Loading.WaitToClickable(ProgramsOR.Button_WorkoutDays_Identifire, Workout_Days_Path);
		WorkoutDays.click();
		}
		else
		{
			WorkoutDays = Loading.WaitToClickable(ProgramsOR.Button_WorkoutDays_Identifire,ProgramsOR.Button_WorkoutDays_Identifire_Default );
			WorkoutDays.click();
		}	
		
	 // Click on Next button
		Next2 = Loading.WaitToClickable(ProgramsOR.Button_Next2_Identifire, ProgramsOR.Button_Next2_Identifire_Value);
		Next2.click();
	}
	
	@Test (priority=13)
	//Select workout-types
	 public void selectStyleOfWorkout() throws InterruptedException
	 {   
		// Wait to previous message disappeared
	  boolean IsInvisible =	Loading.elementBecomesInvisible(ProgramsOR.Page_Navigation, ProgramsOR.Page_Navigation_value);
		
		if (IsInvisible = true)
		{
	  //Identify the Style of Workout
		StyleOfWorkout =Loading.WaitToClickable(ProgramsOR.ImageEasy_Identifire, ProgramsOR.ImageEasy_Identifire_Value);
	    String IsSelected = StyleOfWorkout.getAttribute("class");
		  
       
        // Check if Easy is selected //
	    if((IsSelected)!= "dbwf-preference-card active")
	    {
	    	FindMyPerfectFitSelect = Loading.WaitToClickable(ProgramsOR.ImageEasy_Identifire2, ProgramsOR.ImageEasy_Identifire_Value2);
	    	FindMyPerfectFitSelect.click();
	    }
       
	    // Click on Find MyPerfect Fit button
        FindMyPerfectFit = Loading.WaitToClickable(ProgramsOR.Button_FindMyPerfectFit_Identifire, ProgramsOR.Button_FindMyPerfectFit_Identifire_Value);
        FindMyPerfectFit.click();
            	
		}
	 }
	
	@Test (priority=14)
	// Validate workout preferance saved
	public void workoutPreferanceSaved() throws IOException
	{  
		Loading.WaitToVisible(ProgramsOR.Page_Navigation, ProgramsOR.Page_Navigation_value);
		PreferanceValidationText = Loading.WaitToClickable(ProgramsOR.Message_Text_Identifire, ProgramsOR.Message_Test_Identifire_Value);
	    String PreferanceMessage=  (read_Properties.readProperties("\\src\\test\\java\\com\\diaspark\\dailyburn\\properties\\ProgramsPagePropertise")).getProperty("Programe_Prefereance_Message");
	    Assert.assertEquals(PreferanceValidationText.getText(), PreferanceMessage);
	}
	
	
}
	
	
	
	
	
	


