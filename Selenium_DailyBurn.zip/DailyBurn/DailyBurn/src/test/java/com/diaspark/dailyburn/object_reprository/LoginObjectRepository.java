package com.diaspark.dailyburn.object_reprository;

public class LoginObjectRepository {

	public String SignIn_Identifire                    = "xpath";
	public String SignIn_Identifire_value              = "/html/body/div[2]/div/header/div[2]/div[1]/div[1]/p";
	public String UserName_Identifire                  = "xpath";
	public String UserName_Identifire_value            = "/html/body/div[2]/div/div/div/div/div[1]/div[4]/form/div[1]/div/div/input";
	public String Password_Identifire                  = "xpath";
	public String Password_Identifire_value            = "/html/body/div[2]/div/div/div/div/div[1]/div[4]/form/div[2]/div[1]/div/input";
	public String SignButton_Identifire                = "className";
	public String SignButton_Identifire_value          = "sign-in-btn";
	public String LastLoadedElement_Identifire         = "xpath";
	public String LastLoadedElement_Identifire_value   = "/html/body/div[2]/div/div[2]/div/div[3]/div[2]/div[1]/a";
	                                                          
}

