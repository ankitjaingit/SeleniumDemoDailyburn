package com.diaspark.dailyburn.testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.diaspark.dailyburn.object_reprository.WorkoutsObjectRepository;
import com.diaspark.dailyburn.util.DriverInstance;
import com.diaspark.dailyburn.util.ReadProperties;
import com.diaspark.dailyburn.util.SearchElement;
import com.diaspark.dailyburn.util.WaitToLoad;

public class ManageWorkouts 
{
	public String XpathPart1;
	public String XpathPart2;
	public String XpathPart3;
	public String Filter_Complete_Xpath;
	public String VerifyText;
    public int AllWorkOuts,Easy_WorkOuts_Number,Medium_WorkOuts_Number,Hard_WorkOuts_Number;
	public WebElement Workouts,TotalWorkout,Easy,Medium,Hard,FilterCount,EasyCount,MediumCount,HardCount,LoadMoreWorkouts,WorkoutText;
	public  WebDriver ap_driver =DriverInstance.app_driver;
	WorkoutsObjectRepository WorkoutsOR = new WorkoutsObjectRepository();
	ReadProperties read_Properties = new ReadProperties();
	SearchElement search_Element = new SearchElement();
	WaitToLoad Loading = new WaitToLoad();
		    
	// Get the complete workouts details
	@Test (priority=4)
	   public void navigateToWorkouts() throws IOException, InterruptedException
		{
			
		// Click on Workouts link
		   Workouts = Loading.WaitToClickable(WorkoutsOR.Link_Workout_Identifire, WorkoutsOR.Link_Workout_Identifire_Value);
		   Workouts.click();
		 
		// Get total workouts count
		   TotalWorkout = Loading.WaitToClickable(WorkoutsOR.Filter_TextCount_Identifire, WorkoutsOR.Filter_TextCount_Identifire_Value);
		   String Total_Workouts =  TotalWorkout.getText();
		   String [] Workouts  = Total_Workouts.split(" ");
	       AllWorkOuts = Integer.parseInt(Workouts[0]);
	     }
	 
	// Verify the filter functionality of Easy Workouts
	@Test (priority=5)
	  public void easyFilterVerification()
	  {
		   Easy =Loading.WaitToClickable(WorkoutsOR.Filter_Easy_Identifire, WorkoutsOR.Filter_Easy_Identifire_Value);
		   Easy.click();
		   EasyCount = Loading.WaitToClickable(WorkoutsOR.Filter_TextCount_Identifire, WorkoutsOR.Filter_TextCount_Identifire_Value);
		   String Total_Workouts =  EasyCount.getText();
		   String [] Easy_Workouts  = Total_Workouts.split(" ");
	       Easy_WorkOuts_Number = Integer.parseInt(Easy_Workouts[0]);
	       
	      // Verify the filter data displayed in Easy Section 
	       for(int i =1; i<=Easy_WorkOuts_Number; i++)
	         {
	    	   XpathPart1 =  WorkoutsOR.Filter_Data_Part1;
	    	   XpathPart2 =  WorkoutsOR.Filter_Data_Part2;
	    	   XpathPart3 =  Integer.toString(i);	        	 
	    	   Filter_Complete_Xpath =  XpathPart1+XpathPart3+XpathPart2;
	    	
	      //Click to load more data	 	 
	    	   Boolean toLoadMore = ap_driver.findElements(By.xpath(Filter_Complete_Xpath)).size() > 0;
	    	   
	        	if(toLoadMore!=true)
	        	{
	        		Loading.WaitToClickable(WorkoutsOR.LastLoadedElement_Identifire, WorkoutsOR.Button_LoadMoreWorkout_Identifire_Value).click();
	        	}
	        	WorkoutText = Loading.WaitToVisible(WorkoutsOR.Filter_Value_Identifire, Filter_Complete_Xpath) ;
	        	VerifyText = WorkoutText.getText();
	        	Assert.assertEquals(Easy.getText(),VerifyText);
	 
	        }
	  }

	// Verify the filter functionality of Medium Workouts
    @Test (priority=6)
	 public void mediumFilterVerification()
	 	  {
	 		   Medium =Loading.WaitToClickable(WorkoutsOR.Filter_Medium_Identifire, WorkoutsOR.Filter_Medium_Identifire_Value);
	 		   Medium.click();
	 		   MediumCount = Loading.WaitToClickable(WorkoutsOR.Filter_TextCount_Identifire, WorkoutsOR.Filter_TextCount_Identifire_Value);
	 		   String Total_Workouts =  MediumCount.getText();
	 		   String [] Medium_Workouts  = Total_Workouts.split(" ");
	 	       Medium_WorkOuts_Number = Integer.parseInt(Medium_Workouts[0]);
	 	       
	 	      // Verify the filter data displayed in Medium Section 
	 	       for(int i =1; i<=Medium_WorkOuts_Number; i++)
	 	         {
	 	    	   XpathPart1 =  WorkoutsOR.Filter_Data_Part1;
	 	    	   XpathPart2 =  WorkoutsOR.Filter_Data_Part2;
	 	    	   XpathPart3 =  Integer.toString(i);	        	 
	 	    	   Filter_Complete_Xpath =  XpathPart1+XpathPart3+XpathPart2;
	 	    	
	 	      //Click to load more data	 	 
	 	    	   Boolean toLoadMore = ap_driver.findElements(By.xpath(Filter_Complete_Xpath)).size()> 0;
	 	    	   
	 	        	if(toLoadMore!=true)
	 	        	{
	 	        		Loading.WaitToClickable(WorkoutsOR.LastLoadedElement_Identifire, WorkoutsOR.Button_LoadMoreWorkout_Identifire_Value).click();
	 	        	}
	 	        	WorkoutText = Loading.WaitToVisible(WorkoutsOR.Filter_Value_Identifire, Filter_Complete_Xpath) ;
	 	        	VerifyText = WorkoutText.getText();
	 	        	Assert.assertEquals(Medium.getText(),VerifyText);
	 	 
	 	        }
	     
	  }
    
    // Verify the filter functionality of Hard Workouts
    @Test (priority=7)
	 public void hardFilterVerification()
	 	  {
	 		   Hard =Loading.WaitToClickable(WorkoutsOR.Filter_Hard_Identifire, WorkoutsOR.Filter_Hard_Identifire_Value);
	 		   Hard.click();
	 		   HardCount = Loading.WaitToClickable(WorkoutsOR.Filter_TextCount_Identifire, WorkoutsOR.Filter_TextCount_Identifire_Value);
	 		   String Total_Workouts =  MediumCount.getText();
	 		   String [] Hard_Workouts  = Total_Workouts.split(" ");
	 	       Hard_WorkOuts_Number = Integer.parseInt(Hard_Workouts[0]);
	 	       
	 	      // Verify the filter data displayed in Hard Section 
	 	       for(int i =1; i<=Hard_WorkOuts_Number; i++)
	 	         {
	 	    	   XpathPart1 =  WorkoutsOR.Filter_Data_Part1;
	 	    	   XpathPart2 =  WorkoutsOR.Filter_Data_Part2;
	 	    	   XpathPart3 =  Integer.toString(i);	        	 
	 	    	   Filter_Complete_Xpath =  XpathPart1+XpathPart3+XpathPart2;
	 	    	
	 	      //Click to load more data	 	 
	 	    	   Boolean toLoadMore = ap_driver.findElements(By.xpath(Filter_Complete_Xpath)).size()> 0;
	 	    	   
	 	        	if(toLoadMore!=true)
	 	        	{
	 	        		Loading.WaitToClickable(WorkoutsOR.LastLoadedElement_Identifire, WorkoutsOR.Button_LoadMoreWorkout_Identifire_Value).click();
	 	        	}
	 	        	WorkoutText = Loading.WaitToVisible(WorkoutsOR.Filter_Value_Identifire, Filter_Complete_Xpath) ;
	 	        	VerifyText = WorkoutText.getText();
	 	        	Assert.assertEquals(Hard.getText(),VerifyText);
	 	 
	 	        }
	     
	  }
    
    // Verify the All workouts counts equal to total workouts count
    
    @Test (priority=8)
    
    public void filterCountVerification()
    {
    	
    	int Total_Workouts_Count = Easy_WorkOuts_Number+Medium_WorkOuts_Number+Hard_WorkOuts_Number;
    	Assert.assertEquals(AllWorkOuts, Total_Workouts_Count);
    	
    }
    
    
    
   } 

