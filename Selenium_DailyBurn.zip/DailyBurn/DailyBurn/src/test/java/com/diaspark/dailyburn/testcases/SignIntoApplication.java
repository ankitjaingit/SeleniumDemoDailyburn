package com.diaspark.dailyburn.testcases;
import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.diaspark.dailyburn.object_reprository.LoginObjectRepository;
import com.diaspark.dailyburn.util.*;


public class SignIntoApplication 
{
	public WebElement SignIn,UserName,Password,LogIn,LastLoadedObject;
	public String AfterLoginURL;
	public static WebDriver ap_driver;	
	LoginObjectRepository LoginOR = new LoginObjectRepository();
	ReadProperties read_Properties = new ReadProperties();
	SearchElement search_Element = new SearchElement();
	WaitToLoad Loading = new WaitToLoad();
				
	@Test(priority=1) 
	   public void signIntoApplication() throws IOException, InterruptedException
		{
		ap_driver = DriverInstance.app_driver;
		
		// Launch application
		ap_driver.get(read_Properties.readProperties("\\src\\test\\java\\com\\diaspark\\dailyburn\\properties\\loginPagePropertise").getProperty("URL"));
				
		// Click on SignIn Button		
		   SignIn = Loading.WaitToClickable(LoginOR.SignIn_Identifire, LoginOR.SignIn_Identifire_value);
		   SignIn.click();
	    		
	   // Enter User Name
	       UserName = Loading.WaitToVisible(LoginOR.UserName_Identifire, LoginOR.UserName_Identifire_value);
		   UserName.sendKeys(read_Properties.readProperties("\\src\\test\\java\\com\\diaspark\\dailyburn\\properties\\loginPagePropertise").getProperty("UserName"));
		   
	   // Enter Password
		  Password = Loading.WaitToVisible(LoginOR.Password_Identifire, LoginOR.Password_Identifire_value);
		  Password.sendKeys(read_Properties.readProperties("\\src\\test\\java\\com\\diaspark\\dailyburn\\properties\\loginPagePropertise").getProperty("Password"));
		
		// Click on Sign Button
		
		LogIn = Loading.WaitToClickable(LoginOR.SignButton_Identifire, LoginOR.SignButton_Identifire_value);
		LogIn.click();
		 
		}
	
	@Test(priority=2)
		//Verify login is Successful
		public  void loginSuccessful() throws IOException 
		{
		 String LoginSuccess = read_Properties.readProperties("\\src\\test\\java\\com\\diaspark\\dailyburn\\properties\\loginPagePropertise").getProperty("URL_After_Login");
	     Loading.UntilTextEqual(LoginSuccess);
	     Assert.assertEquals(ap_driver.getCurrentUrl(),LoginSuccess);
		}
	
	@Test(priority=3)
	// Wait to load complete navigation
	   public void NavigateToHome()
	   {
		   Loading.WaitToClickable(LoginOR.LastLoadedElement_Identifire, LoginOR.LastLoadedElement_Identifire_value);
		   
	   }
	   

}
