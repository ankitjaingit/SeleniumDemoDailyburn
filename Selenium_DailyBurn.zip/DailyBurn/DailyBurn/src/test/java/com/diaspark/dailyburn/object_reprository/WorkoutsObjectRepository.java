package com.diaspark.dailyburn.object_reprository;


public class WorkoutsObjectRepository 
{ 
	
	public String Link_Workout_Identifire                      = "xpath";
	public String Link_Workout_Identifire_Value                = "/html/body/div[2]/div/div[1]/div[1]/section[1]/ul/li[3]/a";
	public String Filter_Easy_Identifire                       = "xpath";
	public String Filter_Easy_Identifire_Value                 = "/html/body/div[2]/div/div[2]/div/div[3]/section[2]/div[1]/div[1]/div[7]/div/ul/li[1]";
	public String Filter_Medium_Identifire                     = "xpath";
	public String Filter_Medium_Identifire_Value               = "/html/body/div[2]/div/div[2]/div/div[3]/section[2]/div[1]/div[1]/div[7]/div/ul/li[2]";
	public String Filter_Hard_Identifire                       = "xpath";
	public String Filter_Hard_Identifire_Value                 = "/html/body/div[2]/div/div[2]/div/div[3]/section[2]/div[1]/div[1]/div[7]/div/ul/li[3]";  
	public String Filter_TextCount_Identifire                  = "xpath";
	public String Filter_TextCount_Identifire_Value            = "/html/body/div[2]/div/div[2]/div/div[3]/section[2]/div[1]/div[2]/div[1]";
	public String Button_LoadMoreWorkout_Identifire            = "xpath";
	public String Button_LoadMoreWorkout_Identifire_Value      = "/html/body/div[2]/div/div[2]/div/div[3]/section[2]/div[1]/div[2]/div[4]/button";
	public String LastLoadedElement_Identifire                 = "xpath";
	public String LastLoadedElement_Identifire_value           = "/html/body/div[2]/div/div[2]/div/div[3]/div[2]/div[1]/a";
	public String Filter_Data_Part1                            = "/html/body/div[2]/div/div[2]/div/div[3]/section[2]/div[1]/div[2]/div[3]/div[";                                 
	public String Filter_Data_Part2                            = "]/div/a/div[2]/div/div[3]"; 
	public String Filter_Value_Identifire                      = "xpath";
}
