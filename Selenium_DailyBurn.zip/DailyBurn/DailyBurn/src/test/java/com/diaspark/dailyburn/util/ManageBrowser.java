package com.diaspark.dailyburn.util;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class ManageBrowser {
	
	public static String Selected_Browser;

	public static WebDriver  driver;
	
	public static WebDriver setBrowser()  
	{
	ReadProperties  Readinfo = new ReadProperties();
	
	try {
	Selected_Browser = Readinfo.readProperties("\\src\\test\\java\\com\\diaspark\\dailyburn\\properties\\loginPagePropertise").getProperty("Intend_Browser");
	
	if (Selected_Browser.equalsIgnoreCase("chrome")!= false)
		
    	{
		System.setProperty("webdriver.chrome.driver","D:\\BrowserDrivers\\chromedriver.exe");
		driver = new  ChromeDriver();
        driver.manage().window().maximize();
	}
	else if (Selected_Browser.equalsIgnoreCase("firefox")!= false)
	{
		System.setProperty("webdriver.chrome.driver","D:\\BrowserDrivers\\geckodriver");
		driver = new  FirefoxDriver();
        driver.manage().window().maximize();
        
	}
	else 
	{
		System.setProperty("webdriver.chrome.driver","D:\\BrowserDrivers\\chromedriver.exe");
		driver = new  ChromeDriver();
        driver.manage().window().maximize();
	}
	}
	 
	catch (IOException e) 
    { 
     e.printStackTrace();
    }
	return driver;
	
	}
     
}
