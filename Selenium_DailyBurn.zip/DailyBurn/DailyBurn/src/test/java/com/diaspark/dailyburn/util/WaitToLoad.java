package com.diaspark.dailyburn.util;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitToLoad

{		WebDriver Wait_driver = DriverInstance.app_driver;
		WebDriverWait wait= new WebDriverWait(Wait_driver,120);
		WebElement obj_ele=null; 
		boolean isVisible;

	public WebElement WaitToClickable(String identifier, String value)
	{
		switch (identifier)
		{
		  case "id":
		     obj_ele = wait.until(ExpectedConditions.elementToBeClickable(By.id(value)));
		  break;
		  
		  case"className":
			  obj_ele = wait.until(ExpectedConditions.elementToBeClickable(By.className(value)));
		  break;
			
	      case"xpath":
	    	  obj_ele = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(value)));
	      break;	
	      
		   case"tagName":
			   obj_ele = wait.until(ExpectedConditions.elementToBeClickable(By.tagName(value)));
		   break;	
		}
		return obj_ele;
	}
	
	public WebElement WaitToVisible(String identifier, String value)
	{
		switch (identifier)
		{
		  case "id":
		     obj_ele = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(value)));
		  break;
		  
		  case"className":
			  obj_ele = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(value)));
		  break;
			
	      case"xpath":
	    	  obj_ele = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(value)));
	      break;	
	      
		   case"tagName":
			   obj_ele = wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName(value)));
		   break;	
		}
		return obj_ele;
	}
  public void UntilTextEqual(String text)
  {
	  wait.until(ExpectedConditions.urlToBe(text));
	
  }
  
  public boolean elementBecomesInvisible(String identifier, String value)
	{
		switch (identifier)
		{
		  case "id":
			  isVisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id(value)));
		 
		     break;
		  
		  case"className":
			  isVisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className(value)));
		  break;
			
	      case"xpath":
	    	  isVisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(value)));
	      break;	
  
		}
		return isVisible;
	}
}
